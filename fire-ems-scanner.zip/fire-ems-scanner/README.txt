FIRE / EMS SCANNER (demo)

To run: open index.html in a browser.

For the TALK (microphone) button to work, the page must be served over
https or from localhost. Opening the file directly may block the mic.
Easy options:
  - Upload the folder to a free host (Netlify Drop, GitHub Pages, Cloudflare Pages)
  - Or run:  python3 -m http.server 8000   then open http://localhost:8000

Calls, units, addresses and frequencies are simulated.
